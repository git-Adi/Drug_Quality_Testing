from django.apps import AppConfig


class ZombieAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'zombie_app'
