from chembl_webresource_client.new_client import new_client
molecule = new_client.molecule
